function showcolor(C)
figure(1638);
v = [0,0;1,0;1,1;0,1];
f = [1,2,3,4];
patch('Vertices',v,'Faces',f,'FaceColor',C)
end

