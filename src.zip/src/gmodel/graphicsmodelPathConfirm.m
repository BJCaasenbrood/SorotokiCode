function LatestRelease = graphicsmodelPathConfirm
lib = 'gmdl.lib';
ver = '3.0';
LatestRelease = CheckLibary(lib,ver);
end
