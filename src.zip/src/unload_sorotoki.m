function unload_sorotoki
rmpath(genpath('../SorotokiCode'))
end

