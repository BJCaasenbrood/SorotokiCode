function Material = Dragonskin30A
D = 1.0;
Material = YeohMaterial('C1',1.19e-3,'C2',2.3028e-2,'C3',1e-12,...
    'D1',D,'D2',1e-3,'D3',1e-3);
end

