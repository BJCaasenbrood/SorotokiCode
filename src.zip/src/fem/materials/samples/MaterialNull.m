function Material = MaterialNull
Material=  LinearMaterial('E',50,'Nu',0.3);
end

