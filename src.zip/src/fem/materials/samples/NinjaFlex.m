function Material = NinjaFlex
Material=  NeoHookeanMaterial('E',12,'Nu',.4);
end

