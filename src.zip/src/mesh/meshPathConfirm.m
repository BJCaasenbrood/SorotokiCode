function LatestRelease = meshPathConfirm
lib = 'mesh.lib';
ver = '3.0';
LatestRelease = CheckLibary(lib,ver);
end
