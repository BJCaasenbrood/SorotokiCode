function LatestRelease = basePathConfirm
lib = 'base.lib';
ver = '3.0';
LatestRelease = CheckLibary(lib,ver);
end
