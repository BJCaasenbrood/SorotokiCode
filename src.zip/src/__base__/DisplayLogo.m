
function DisplayLogo
clc;
if ispc
fprintf('\t\t\t\n');
fprintf(' -------------------------------------------------------------------------- \n');
fprintf('\t\t\t  < S O F T    R O B O T I C S    T O O L K I T > \n');
fprintf(' -------------------------------------------------------------------------- \n');
fprintf(['\t\t\t     Current version: ', BuildVersion, ' (',date,')\n'])
fprintf('\t\t\t\t    Written by b.j.caasenbrood - TU/e \n');
fprintf(['\t\t\t\t\t\t      ', PatchInfo(3), '\n']);
fprintf(' -------------------------------------------------------------------------- \n');
fprintf('\t\t\t\n');
elseif isunix || ismac
fprintf('\t\t\t\n');
fprintf(' -------------------------------------------------------------------------- \n');
fprintf('\t\t  < S O F T    R O B O T I C S    T O O L K I T > \n');
fprintf(' -------------------------------------------------------------------------- \n');
fprintf(['\t\t     Current version: ', BuildVersion, ' (',date,')\n'])
fprintf('\t\t      Written by b.j.caasenbrood - TU/e \n');
fprintf(['\t\t\t      ', PatchInfo(3), '\n']);
fprintf(' -------------------------------------------------------------------------- \n');
fprintf('\t\t\t\n');
end
    
end