function bool = isodd(a)
%ISODD.m  checks if scalar is odd, returns boolean
bool = logical(rem(a,2));
end

