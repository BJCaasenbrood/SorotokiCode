function y = tria(x)
y = max(-abs(2*x-1)+1,0);
end

