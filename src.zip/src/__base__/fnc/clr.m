%CLR executes clc + clear + close all 
clc;
clear;
close all;
