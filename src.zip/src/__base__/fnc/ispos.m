function y = ispos(x)
%ISNEG.m  checks if scalar is positive, returns boolean
if x > 0, y = true;
else, y = false;
end
end

