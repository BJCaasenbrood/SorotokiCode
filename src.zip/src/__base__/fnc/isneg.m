function y = isneg(x)
%ISNEG.m  checks if scalar is negative, returns boolean
if x < 0, y = true;
else, y = false;
end
end

