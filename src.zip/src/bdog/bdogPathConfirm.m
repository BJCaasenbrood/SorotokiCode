function LatestRelease = bdogPathConfirm
lib = 'bdog.lib';
ver = '3.0';
LatestRelease = CheckLibary(lib,ver);
end

