function y = chebyshev(x,n)
y =  cos(n*acos((2*x)-1));
end

