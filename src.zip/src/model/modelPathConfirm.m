function LatestRelease = modelPathConfirm
lib = 'model.lib';
ver = '3.0';
LatestRelease = CheckLibary(lib,ver);
end
