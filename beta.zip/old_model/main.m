%% load dependencies
make();

%% 
mdl = SRModel();

tic;
y = mdl.configspace();
toc;

hold on;
plot3(y(:,1),y(:,2),y(:,3),'linewidth',1)

Y = diff(y); sum(sum(abs(Y),2))