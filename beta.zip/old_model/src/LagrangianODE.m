function  DX = LagrangianODE(s, x)
n = length(x)/2;
M = zeros(n,n);
C = zeros(n,n);
N = zeros(n,n);


M = J.'*Lambda*J;
C = dJ.'*Lambda*J + ;
N = 

end

