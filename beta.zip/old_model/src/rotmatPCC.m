function R = rotmatPCC(s,x)
kappa_x = x(2);
kappa_y = x(3);
kappa = sqrt(kappa_x^2 + kappa_y^2);
alpha = kappa*s;

ca = cos(alpha);
sa = sin(alpha);
va = 1-ca;

kx = -(kappa_y/kappa);
ky = (kappa_x/kappa);

R = [((kx^2)*va) + ca, (kx*ky*va), (ky*sa);
     (kx*ky*va), ((ky^2)*va) + ca, -(kx*sa);
     -(ky*sa), (kx*sa),  ca];

end

