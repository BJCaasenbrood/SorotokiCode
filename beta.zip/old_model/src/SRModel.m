classdef SRModel

properties (Access = public)
	Phi;
    NDisc;
    Density;
    Radius;
    q;
end
properties (Access = public)
    Area;
    Jxx, Jyy, Jzz;
    Jom;
    Jh;
end   


methods (Access = public)
    
%-------------------------------------------------------------- Model Class
function obj = SRModel(varargin) 
    
    obj.NDisc = 2;
    obj.Density = 2;
    obj.Radius = 2;
    obj.q = [1,0,0,-0,0,0].';
    obj.Phi = @(x) generateShape(obj,x);
    obj.Jom = jacobianWStates(obj);
    obj.Jh = jacobianHStates(obj);
    
    for ii = 1:2:length(varargin)
        obj.(varargin{ii}) = varargin{ii+1};
    end
    
end

%---------------------------------------------------------------------- get     
function varargout = get(SRModel,varargin)
    if nargin > 1
        varargout{nargin-1,1} = [];
        for ii = 1:length(varargin)
            varargout{ii,1} = SRModel.(varargin{ii});
        end
    else
        varargout = SRModel.(varargin);
    end
end
        
%---------------------------------------------------------------------- set
function SRModel = set(SRModel,varargin)
    for ii = 1:2:length(varargin)
        Model.(varargin{ii}) = varargin{ii+1};
    end
end
 
%---------------------------------------------------------------------- set    
function P = generateShape(SRModel,s)
Pc = cell(3,1);
X = single(s);

if SRModel.NDisc>1
    P11 = 1;
    P22 = 1;
else
    P11 = 1;
end

if SRModel.NDisc>1
    for ii = 1
         P11(1,ii) = sign(z1(X)).*1;
         P22(1,ii) = sign(z2(X)).*1;
    end
    P = horzcat(P11,P22);
else
    for ii = 1
        P11(1,ii) = 1;
    end
    P = P11;
end

for ii = 1:3
    Pc{ii,1} = P; 
end

P = blkdiag(Pc{:})+ 1e-26*X;

function y = z1(x)
y = 2*max((sign(-2.0*x+1.0)),0.0)*x;
end

function y = z2(x)
y = max((2.0*(x)-1.0),0.0);
end

end

%---------------------------------------------------------------------- set    
function Jw = jacobianWStates(SRModel)
    Jw = [0,0,-1;0,1,0;0,0,0];
end

%---------------------------------------------------------------------- set    
function Jh = jacobianHStates(SRModel)
    Jh = [0,0,0;0,0,0;1,0,0];
end

%----------------------------------------------------------------- simulate
function SRModel = generateinertia(SRModel)
    SRModel.Area = pi*SRModel.Radius^2;
    SRModel.Jxx  = 0.5*SRModel.Density*SRModel.Radius^2;
    SRModel.Jyy  = 0.25*SRModel.Density*SRModel.Radius^2;
    SRModel.Jzz  = 0.25*SRModel.Density*SRModel.Radius^2; 
end
    
%---------------------------------------------------------------------- set    
function y = configspace(SRModel)
    
    N = 100;
    x = SRModel.q;
    p = zeros(3,1);
    R = eye(3);
    
    S = linspace(1e-6,.5,N);
    ds = mean(diff(S));
    
    s = 1e-12;
    y = zeros(N,3);
    
    for ii = 1:length(S)
        [dp1,dR1] = ForwardKinematics(SRModel,s,x,R,p);
               
        s = s + ds;
        p = p + ds*dp1;
        R = R + ds*dR1;
        
        y(ii,:) = p;
    end

end
    
%---------------------------------------------------------------------- set  
function [dp,dR] = ForwardKinematics(SRModel,s,x,R,p)
    
    P  = SRModel.Phi(s);
    JW = SRModel.Jom;
    JH = SRModel.Jh;
    
    xi_w = isomSO3(JW*P*x);
    xi_h = JH*P*x;
    
    dR = R*xi_w;
    dp = R*xi_h;
    
end


end  
    
end

